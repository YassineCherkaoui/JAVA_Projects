package Employee;

public class EmployeHoraire extends Employee {
	private double taux_horair;
		private int houre;
		
		
		
		
		public EmployeHoraire(String nom, String prenom,double taux_horair,int houre) {
			super(nom, prenom);
			// TODO Auto-generated constructor stub
			this.taux_horair = taux_horair;
			this.houre = houre;	
		}

		public double calculSalaire() {
			return taux_horair*houre;
		}
		@Override
		public String toString(){
			return super.toString()+ " Salair ="+calculSalaire()+ " DH";
		}

		@Override
		public void afficherEmployee() {
			// TODO Auto-generated method stub
			System.out.println(toString());
			
		}

	
}
